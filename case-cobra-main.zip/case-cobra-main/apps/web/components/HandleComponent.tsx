import { FC } from 'react'

type Props = {}

const HandleComponent: FC<Props> = ({}) => {
  return (
    <div className='size-5 rounded-full border border-muted-foreground bg-background shadow transition hover:bg-primary' />
  )
}

export default HandleComponent
