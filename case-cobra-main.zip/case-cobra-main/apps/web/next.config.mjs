/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['eyrrwbmzqaulyfivwnbo.supabase.co']
  }
}

export default nextConfig
