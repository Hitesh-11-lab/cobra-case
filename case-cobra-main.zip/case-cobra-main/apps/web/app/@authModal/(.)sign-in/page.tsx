import LoginDialog from '@/components/auth/LoginDialog'
import { FC } from 'react'

type Props = {}

const Page: FC<Props> = ({}) => {
  return <LoginDialog />
}

export default Page
